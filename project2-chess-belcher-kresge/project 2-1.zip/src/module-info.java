module SolitaireChess {
    requires transitive javafx.controls;
    exports soltrchess.gui;
}