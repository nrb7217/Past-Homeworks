package soltrchess.backtracking;/*
 * solitarechess.backtracking.Backtracker.java
 *
 * This file comes from the solitarechess.backtracking lab. It should be useful
 * in this project. A second method has been added that you should
 * implement.
 */

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

/**
 * This class represents the classic recursive solitarechess.backtracking algorithm.
 * It has a solver that can take a valid configuration and return a
 * solution, if one exists.
 * 
 * @author RIT CS
 */
public class Backtracker {
    
    /**
     * Try find a solution, if one exists, for a given configuration.
     * 
     * @param config A valid configuration
     * @return A solution config, or null if no solution
     */
    public Optional<Configuration> solve(Configuration config) {
        if (config.isGoal()) {
            return Optional.of(config);
        } else {
            for (Configuration child : config.getSuccessors()) {
                if (child.isValid()) {
                    Optional<Configuration> sol = solve(child);
                    if (sol.isPresent()) {
                        return sol;
                    }
                }
            }
            // implicit solitarechess.backtracking happens here
        } 
        return Optional.empty();
    }

    /**
     * Find a goal configuration if it exists, and how to get there.
     * @param current the starting configuration
     * @return a list of configurations to get to a goal configuration.
     *         If there are none, return null.
     */
    public List< Configuration > solveWithPath( Configuration current ) {
        // YOUR CODE HERE
        return null;
    }

}

/**
 * TODO: Create a new class called ChessSolver, with a main method like the one in Skyscrapers vvv that call this to do the back tracking
 */
/*

public class Skyscraper {
    */
/**
     * The main program.
     * @param args command line arguments
     * @throws FileNotFoundException if file not found
     *//*

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 2) {
            System.err.println("Usage: java Skyscraper file debug");
        } else {
            // pass scanner object to constructor to read initial board
            String fileName = args[0];
            SkyscraperConfig initConfig = new SkyscraperConfig(fileName);

            boolean debug = args[1].equals("true");
            System.out.println("File: " + fileName);
            System.out.println("Debug: " + debug);
            System.out.println("Initial config:");
            System.out.println(initConfig);

            // create the backtracker with the debug flag
            Backtracker bt = new Backtracker(debug);

            // start the clock
            double start = System.currentTimeMillis();

            // solve the puzzle
            Optional<Configuration> solution = bt.solve(initConfig);

            // compute the elapsed time
            double elapsed = (System.currentTimeMillis() - start) / 1000.0;

            // display the solution, if one exists
            if (solution.isPresent()) {
                System.out.println("Solution:\n" + solution.get());
            } else {
                System.out.println("No solution");
            }

            System.out.println("Elapsed time: " + elapsed + " seconds.");
        }
    }
} */
