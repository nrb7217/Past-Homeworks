package soltrchess.ptui;

import soltrchess.model.Observer;
import soltrchess.model.SoltrChessModel;

import java.io.FileNotFoundException;

public class SoltrChessPTUI implements Observer<SoltrChessModel, String> {

    public SoltrChessModel model;
    /**
     * Construct the PTUI
     *
     * @param filename the file name
     */
    public SoltrChessPTUI(String filename) throws FileNotFoundException {
        this.model = new SoltrChessModel();
        initializeView();
    }

    private void initializeView() {this.model.addObserver(this); }
    /**
     * The main command loop.
     */
    public void run() {

    }

    @Override
    public void update(SoltrChessModel soltrChessModel, String s) {
        System.out.print(this.model);
        System.out.println("Status " + this.model.getGameStatus());
    }
}